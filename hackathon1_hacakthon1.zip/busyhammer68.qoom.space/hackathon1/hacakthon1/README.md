safe search.
==================
## This project generates a website which has several tabs- one such being a password generator to help you make complex passwords that no one can guess

## This project is a step forward for cybersecurity and with the breach log, a great way to keep yourself and information safe

## I built this using Html, JS, and CSS 

## This was my first ever website that I made and I'm really proud of myself for creating something tangible! 

## I hope to find a way to create a breach log tab so that I can help more people with cybersecurity!